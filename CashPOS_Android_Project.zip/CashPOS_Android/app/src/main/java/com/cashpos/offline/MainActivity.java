package com.cashpos.offline;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.IOException;
import java.io.InputStream;

public class MainActivity extends Activity {
    private WebView webView;
    private PermissionRequest pendingRequest;
    private static final int CAMERA_REQUEST = 9001;
    private static final String APP_ORIGIN = "https://cashpos.local/";

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(false);

        webView.setWebViewClient(new LocalClient());
        webView.setWebChromeClient(new CameraChromeClient());
        webView.loadUrl(APP_ORIGIN + "index.html");
    }

    private boolean hasCamera() {
        return checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestCamera(PermissionRequest request) {
        pendingRequest = request;
        if (hasCamera()) {
            grantCamera(request);
        } else {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_REQUEST);
        }
    }

    private void grantCamera(PermissionRequest request) {
        if (request != null) {
            request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
        }
        pendingRequest = null;
    }

    private void denyCamera(PermissionRequest request) {
        if (request != null) request.deny();
        pendingRequest = null;
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) grantCamera(pendingRequest);
            else denyCamera(pendingRequest);
        }
    }

    @Override protected void onDestroy() {
        if (webView != null) { webView.stopLoading(); webView.destroy(); }
        super.onDestroy();
    }

    private class CameraChromeClient extends WebChromeClient {
        @Override public void onPermissionRequest(final PermissionRequest request) {
            runOnUiThread(() -> {
                String origin = request.getOrigin() == null ? "" : request.getOrigin().toString();
                if (origin.startsWith(APP_ORIGIN) && containsVideo(request.getResources())) requestCamera(request);
                else denyCamera(request);
            });
        }
        private boolean containsVideo(String[] resources) {
            for (String r : resources) if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) return true;
            return false;
        }
    }

    private class LocalClient extends WebViewClient {
        @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            return serve(request.getUrl().toString());
        }
        @Override public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
            return serve(url);
        }
        private WebResourceResponse serve(String url) {
            if (!url.startsWith(APP_ORIGIN)) return null;
            String path = url.substring(APP_ORIGIN.length());
            if (path.isEmpty()) path = "index.html";
            try {
                InputStream in = getAssets().open(path);
                String mime = path.endsWith(".html") ? "text/html" : "application/octet-stream";
                String encoding = path.endsWith(".html") ? "UTF-8" : null;
                return new WebResourceResponse(mime, encoding, in);
            } catch (IOException e) { return null; }
        }
    }
}
